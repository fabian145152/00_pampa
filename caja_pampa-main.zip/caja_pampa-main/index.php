<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pampa</title>
    <link rel="stylesheet" href="css/detalles.css">
</head>

<body>
    <h1>Inicio</h1>
    <a href="listado_pampa_porte/index.php" class="boton" target="_blank" rel="noopener noreferrer">LISTADO PAMPA PORTE</a>
    <br><br>
    <a href="excel/index.php" class="boton" target="_blank" rel="noopener noreferrer">CUENTA 101</a>
    <br><br>
    <a href="caja_con_excel/inicio_caja.php" class="boton" target="_blank" rel="noopener noreferrer">CAJA CON EXCEL</a>
    <br><br>
    <br><br>
    <br><br>
    <br><br>
    <a href="vistas/inicio.php" class="boton" target="_blank" rel="noopener noreferrer">listado Titulares</a>
    <br><br>
    <a href="crear/inicio.php" class="boton" target="_blank" rel="noopener noreferrer">Crear Nueva unidad</a>
    <br><br>
    <a href="editores/inicio.php" class="boton" target="_blank" rel="noopener noreferrer">Editar Titulares, Choferes y unidades</a>
    <br><br>
    <a href="caja/inicio.php" class="boton" target="_blank" rel="noopener noreferrer">Caja Efectivo</a>
    <br><br>
    <a href="caja/abono.php" class="boton" target="_blank" rel="noopener noreferrer">Abonos</a>
    <br><br>
    <a href="voucher/inicio.php" class="boton" target="_blank" rel="noopener noreferrer">carga de Voucher</a>
    <br><br>
    <br><br>


</body>

</html>