<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        html, body {
     min-height: 100%;
}
    </style>
</head>

<body>
    <ul>
        <li>Cargar primero todos los datos del titular</li>
        <li>Crear Crea solo el titular</li>
        <li>Reestablecer borra todos los campos de este formulario</li>
        <li>Luego pulsar 1 o 2 choferes y cargar los datos de cada uni</li>
        <li></li>
    </ul>
</body>

</html>