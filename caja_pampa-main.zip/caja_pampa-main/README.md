# caja_pampa
Ver 1.0   Fecha 06-02-2023
Ver 2.0   Fecha 25-02-2023
Ver 2.1.0   Fecha 03-03-2023

Crur terminados 
6-3-22  cree tabla caja
relacione unidades con caja_cont

20-3-22 ya esta calculo de la deuda por registro
29-3-23 genero registro nuevo con cada pago

Trabajando con la funcion de crear registro nuevo por semana
        por ahora probandolo con segundos

