<?php
//creamos la conexion a la basse de datos
$mysqli = new mysqli("127.0.0.1", "root", "root", "at");
